<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class admin extends Model
{
    use HasFactory;
    protected $fillable = [
        'nama_admin',
        'no_hp_admin',
        'email_admin',
        'password_admin',
    ];
}
