
<?php $__env->startSection('title','List Data Pegawai'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>List Data Pegawai</title>
    
    <style>
    body {
        background-color: lightgray !important;
    }
    </style>
     <?php $__env->startSection('css'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php $__env->stopSection(); ?>
</head>

<body>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 50px">
    <div class="row">
        <div class="col-md-12">
            <h4 class="text-center">Tabel Data Pegawai </h4>
            <div class="card border-0 shadow-sm rounded-md mt-4">
                <div class="card-body">
                    <a href="javascript:void(0)" class="btn btn-success mb-2" id="btn-create-post">TAMBAH</a>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Nama Pegawai</th>
                                <th>Nomor HP</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="table-pegawais">
                            <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="index_<?php echo e($pegawai->id); ?>">
                                <td><?php echo e($pegawai-> nama_pegawai); ?></td>
                                <td><?php echo e($pegawai-> no_hp_pegawai); ?></td>
                                <td><?php echo e($pegawai-> email_pegawai); ?></td>
                                <td><?php echo e($pegawai-> password_pegawai); ?></td>
                                <td class="text-left">
                                <a href="javascript:void(0)"id="btn-edit-post" data-id="<?php echo e($pegawai->id); ?>" class="btn btn-primary btn-sm">EDIT</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('pegawai.modal-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pegawai.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('pegawai.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.pegawai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PCR KULIAH\SEMESTER 5\WPF\Project\project_kel3\kel3-api\resources\views/pegawai/list_pegawai.blade.php ENDPATH**/ ?>