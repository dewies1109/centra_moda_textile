
<?php $__env->startSection('title','List Data Barang'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Laravel Ajax Tabel Barang</title>
    <style>
        body {
            background-color: lightgray !important;
        }
    </style>
    <?php $__env->startSection('css'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php $__env->stopSection(); ?>
</head>
<body>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 50px">
        <div class="row">
            <div class="col-md-12">
            <h4 class="text-center">Tabel Barang </h4>

            <div class="card border-0 shadow-sm rounded-md mt-4">

                <div class="card-body">

                    <a href="javascript:void(0)" class="btn btn-success mb-2" id="btn-create-post">TAMBAH</a>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Jenis Barang</th>
                                <th>Nama Barang</th>
                                <th>Harga Barang</th>
                                <th>Gambar Barang</th>
                                <th>Lebar Kain (cm)</th>
                                <th>Stok</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>

                        <tbody id="table-posts">
                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="index_<?php echo e($barang->id); ?>">
                                <td><?php echo e($barang->id_jenis_barang); ?></td>
                                <td><?php echo e($barang->nama_barang); ?></td>
                                <td><?php echo e($barang->harga_barang); ?></td>
                                <td><img src="<?php echo e(url('storage/barangs/'.$barang->gambar)); ?>" width="50" height="50"></td>
                                <td><?php echo e($barang->lebar_kain); ?></td>
                                <td><?php echo e($barang->stok); ?></td>
                                
                                <td class="text-center">
                                    <a href="javascript:void(0)" id="btn-edit-post" data-id="<?php echo e($barang->id); ?>" class="btn btn-primary btn-sm">EDIT</a>
                                    <!--<a href="javascript:void(0)" id="btn-delete-post" data-id="<?php echo e($barang->id); ?>" class="btn btn-danger btn-sm">DELETE</a>-->
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('barang.modal-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('barang.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.barang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PCR KULIAH\SEMESTER 5\WPF\Project\project_kel3\kel3-api\resources\views/barang/list_barang.blade.php ENDPATH**/ ?>