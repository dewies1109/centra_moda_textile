<script>
//button create post event
$('body').on('click', '#btn-delete-post', function () {
    let post_id = $(this).data('id');
    let token = $("meta[name='csrf-token']").attr("supplier");
        Swal.fire({
        title: 'Apakah Kamu Yakin?',
        text: "ingin menghapus data ini!",
        icon: 'warning',
        showCancelButton: true,
        cancelButtonText: 'TIDAK',
        confirmButtonText: 'YA, HAPUS!'
    }).then((result) => {
        if (result.isConfirmed) {
            console.log('test');
            //fetch to delete data
            $.ajax({
                url: '<?php echo e(url('api/suppliers')); ?>/'+ post_id,
                type: "DELETE",
                cache: false,
                data: {
                    "_token": token
                },
                success:function(response){
                    //show success message

                    Swal.fire({

                        type: 'success',
                        icon: 'success',
                        title: `${response.message}`,
                        showConfirmButton: false,
                        timer: 3000

                    });
                    //remove post on table

                    $(`#index_${post_id}`).remove();

                }
            });

        }
    })
});
</script>
<?php /**PATH D:\PCR KULIAH\SEMESTER 5\WPF\Project\project_kel3\kel3-api\resources\views/supplier/delete.blade.php ENDPATH**/ ?>