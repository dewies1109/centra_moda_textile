
<?php $__env->startSection('title','List Data Supplier'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Laravel Ajax Supplier</title>
    
    <style>
    body {
        background-color: lightgray !important;
    }
    </style>
    <?php $__env->startSection('css'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php $__env->stopSection(); ?>
</head>

<body>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 50px">
    <div class="row">
        <div class="col-md-12">
            <h4 class="text-center">Tabel Data Supplier </h4>
            <div class="card border-0 shadow-sm rounded-md mt-4">
                <div class="card-body">
                    <a href="javascript:void(0)" class="btn btn-success mb-2" id="btn-create-post">TAMBAH</a>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Nama Supplier</th>
                                <th>Nomor HP</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="table-suppliers">
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="index_<?php echo e($supplier->id); ?>">
                                <td><?php echo e($supplier-> nama_supplier); ?></td>
                                <td><?php echo e($supplier-> no_hp_supplier); ?></td>
                                <td><?php echo e($supplier-> email_supplier); ?></td>
                                <td><?php echo e($supplier-> password_supplier); ?></td>
                                <td class="text-left">
                                <a href="javascript:void(0)"id="btn-edit-post" data-id="<?php echo e($supplier->id); ?>" class="btn btn-primary btn-sm">EDIT</a>
                                <!--<a href="javascript:void(0)"id="btn-delete-post" data-id="<?php echo e($supplier->id); ?>" class="btn btn-danger btn-sm">DELETE</a>-->
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('supplier.modal-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('supplier.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('supplier.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.supplier', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PCR KULIAH\SEMESTER 5\WPF\Project\project_kel3\kel3-api\resources\views/supplier/list_supplier.blade.php ENDPATH**/ ?>